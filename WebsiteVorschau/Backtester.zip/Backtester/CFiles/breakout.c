__attribute__((used)) int strategy(float *prices, int length, int intervalsBack) {
    if (length < intervalsBack) {
        return 0;
    }

    int windowLength = length - 1;
    if (windowLength <= 0) {
        return 0;
    }

    float min = prices[0];
    float max = prices[0];

    for (int i = 1; i < windowLength; i++) {
        float v = prices[i];
        if (v < min) {
            min = v;
        }
        if (v > max) {
            max = v;
        }
    }

    float last = prices[length - 1];
    float epsilon = 0.01f;

    float longTrigger = max * (1.0f + epsilon);
    float shortTrigger = min * (1.0f - epsilon);

    if (last > longTrigger) {
        return 1;
    }
    if (last < shortTrigger) {
        return -1;
    }

    return 0;
}
