double sqrt(double x) {
    if (x <= 0) {
        return 0;
    }
    double guess = x;
    for (int i = 0; i < 20; i++) {
        guess = 0.5 * (guess + x / guess);
    }
    return guess;
}
__attribute__((used)) int strategy(float *prices, int length) {
    if (length < 22) {
        return 0;
    }

    float sum = 0;
    for (int i = 0; i < length; i++) {
    sum += prices[i];
    }
    float mean = sum / length;

    float var_sum = 0;
    for (int i = 0; i < length; i++) {
        float diff = prices[i] - mean;
        var_sum += diff * diff;
    }
    float variance = var_sum / length;

    double stdDev = sqrt(variance);

    double upperBand = mean + 3.25 * stdDev;
    double lowerBand = mean - 3.25 * stdDev;

    float lastPrice = prices[length - 1];

    if (lastPrice < lowerBand) {
        return 1;
    }
    if (lastPrice > upperBand) {
        return -1;
    }

    return 0;
}