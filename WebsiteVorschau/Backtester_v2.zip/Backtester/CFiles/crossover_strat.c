float movingAverage(const float *data, int len, int period) {
    if (len < period) {
        return 0.0f;
    }
    float sum = 0.0f;
    for (int i = len - period; i < len; i++) {
        sum += data[i];
    }
    return sum / period;
}

float absf(float value) {
    return value < 0.0f ? -value : value;
}

__attribute__((used)) int strategy(float *prices, int length) {
    const int shortPeriod = 8;
    const int longPeriod = 21;
    
    if (length < longPeriod + 1) {
        return 0;
    }

    float currentPrice = prices[length - 1];
    float thresholdPercentage = 0.002f;
    float threshold = currentPrice * thresholdPercentage;

    float shortPrev = movingAverage(prices, length - 1, shortPeriod);
    float longPrev  = movingAverage(prices, length - 1, longPeriod);
    float shortCurr = movingAverage(prices, length, shortPeriod);
    float longCurr  = movingAverage(prices, length, longPeriod);

    float diffPrev = shortPrev - longPrev;
    float diffCurr = shortCurr - longCurr;

    if (diffPrev < 0 && diffCurr > 0 && absf(diffCurr) >= threshold) {
        return 1;
    }
    if (diffPrev > 0 && diffCurr < 0 && absf(diffCurr) >= threshold) {
        return -1;
    }
    return 0;
}
