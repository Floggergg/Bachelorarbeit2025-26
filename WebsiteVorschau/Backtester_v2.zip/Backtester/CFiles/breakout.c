__attribute__((used)) int strategy(float *prices, int length) {
    if (length < 22) {
        return 0;
    }

    float min = prices[0];
    float max = prices[0];
    for (int i = 1; i < 21; i++) {
        if (prices[i] < min) {
            min = prices[i];
        }
        if (prices[i] > max) {
            max = prices[i];
        }
    }

    float last = prices[21];
    float epsilon = 0.01;

    float longTrigger = max * (1.0 + epsilon);
    float shortTrigger = min * (1.0 - epsilon);

    if (last > longTrigger) {
    return 1;
    }
    if (last < shortTrigger) {
    return -1;
    }
    return 0;
}