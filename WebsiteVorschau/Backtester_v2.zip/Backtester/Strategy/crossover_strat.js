function strategy(prices) {
    function movingAverage(data, period) {
        if (data.length < period) {
            return 0;
        }
        const slice = data.slice(-period);
        const sum = slice.reduce((acc, val) => acc + val, 0);
        return sum / period;
    }

    const shortPeriod = 8;
    const longPeriod = 21;

    if (prices.length < longPeriod + 1) {
        return 0;
    }

    const currentPrice = prices[prices.length - 1];
    const thresholdPercentage = 0.002;
    const threshold = currentPrice * thresholdPercentage;

    const shortPrev = movingAverage(prices.slice(0, -1), shortPeriod);
    const longPrev = movingAverage(prices.slice(0, -1), longPeriod);
    const shortCurr = movingAverage(prices, shortPeriod);
    const longCurr = movingAverage(prices, longPeriod);

    const diffPrev = shortPrev - longPrev;
    const diffCurr = shortCurr - longCurr;

    if (diffPrev < 0 && diffCurr > 0 && Math.abs(diffCurr) >= threshold) {
        return 1;
    }
    if (diffPrev > 0 && diffCurr < 0 && Math.abs(diffCurr) >= threshold) {
        return -1;
    }
    return 0;
}

